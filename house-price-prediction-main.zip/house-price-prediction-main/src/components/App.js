import React from 'react'
import Form from './Form/Form';

const App=()=> {
  return (
    <div>
        <Form/>
    </div>
  )
}
export default App;