Title: House Rent Prediction using LTSM Networks

Initially, the train dataset is loaded. The ‘longitude’, ‘latitude’ and ‘negotiable’ columns have been
removed and all variables of string values in train.csv are converted to integers using Label Encoder.
The ‘rent’ column is place in ‘y’ variable which represents dependent variable and all the other columns
 except are placed in ’x’ variable which represents independent variable. 
A LSTM(Long Short-Term Memory)  Neural Networks is used to create a neural network model and
 there by the model has been trained. The house rent prediction model that is built gives an accuracy of 80% - 85%.